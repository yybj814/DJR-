
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "D:/RM/FreeRTOS/RI2C3333/Core/Startup/startup_stm32f103c8tx.s" "D:/RM/FreeRTOS/RI2C3333/cmake-build-debug/CMakeFiles/RI2C3333.elf.dir/Core/Startup/startup_stm32f103c8tx.s.obj"
  )
set(CMAKE_ASM_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "DEBUG"
  "STM32F103xB"
  "USE_HAL_DRIVER"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "D:/RM/FreeRTOS/RI2C3333/Core/Inc"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Inc/Legacy"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Inc"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/include"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/CMSIS/Device/ST/STM32F1xx/Include"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/CMSIS/Include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/font.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/font.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/font.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/freertos.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/freertos.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/freertos.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/gpio.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/gpio.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/gpio.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/main.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/main.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/main.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/oled.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/oled.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/oled.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/stm32f1xx_hal_msp.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/stm32f1xx_hal_msp.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/stm32f1xx_hal_msp.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/stm32f1xx_it.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/stm32f1xx_it.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/stm32f1xx_it.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/syscalls.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/syscalls.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/syscalls.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/sysmem.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/sysmem.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/sysmem.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/system_stm32f1xx.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/system_stm32f1xx.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/system_stm32f1xx.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Core/Src/usart.c" "CMakeFiles/RI2C3333.elf.dir/Core/Src/usart.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Core/Src/usart.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_uart.c" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_uart.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_uart.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/croutine.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/croutine.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/croutine.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/event_groups.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/event_groups.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/event_groups.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/list.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/list.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/list.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3/port.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3/port.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3/port.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang/heap_4.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang/heap_4.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang/heap_4.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/queue.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/queue.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/queue.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/stream_buffer.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/stream_buffer.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/stream_buffer.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/tasks.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/tasks.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/tasks.c.obj.d"
  "D:/RM/FreeRTOS/RI2C3333/Middlewares/Third_Party/FreeRTOS/Source/timers.c" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/timers.c.obj" "gcc" "CMakeFiles/RI2C3333.elf.dir/Middlewares/Third_Party/FreeRTOS/Source/timers.c.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
