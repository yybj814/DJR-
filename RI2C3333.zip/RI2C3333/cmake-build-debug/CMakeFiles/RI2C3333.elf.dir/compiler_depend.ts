# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for RI2C3333.elf.
