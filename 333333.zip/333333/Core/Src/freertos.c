/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "oled.h"
#include "usart.h"
#include <stdio.h>
#include <string.h>

#include "stm32f1xx_hal_uart.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
volatile uint8_t wroktask = 0;
volatile uint8_t paused = 0;
volatile uint16_t stepMs = 300;


typedef struct {
  uint8_t run;
  uint8_t dir;
  uint16_t step;
} UART_Packet;
volatile UART_Packet gPacket = {1, 1, 300};

static uint8_t rxByte;
static uint8_t pktBuf[6];
static uint8_t pktIdx = 0;


static void UIntToStr(uint16_t v, char *buf)
{
  char tmp[8];
  int i = 0, j = 0;
  if (v == 0) { buf[0] = '0'; buf[1] = 0; return; }
  while (v > 0) { tmp[i++] = (char)('0' + v % 10); v /= 10; }
  while (i > 0) buf[j++] = tmp[--i];
  buf[j] = 0;
}

void OLED_ShowStatus(void)
{
  char line[20];
  char stepStr[8];
  uint8_t ledNo;
  const char *led;

  if (HAL_GPIO_ReadPin(RED_GPIO_Port, RED_Pin) == GPIO_PIN_SET) {
    led = "RED";  ledNo = 1;
  } else if (HAL_GPIO_ReadPin(YELLOW_GPIO_Port, YELLOW_Pin) == GPIO_PIN_SET) {
    led = "YELLOW"; ledNo = 2;
  } else {
    led = "GREEN";  ledNo = 3;
  }

  UIntToStr(stepMs, stepStr);

  OLED_NewFrame();

  strcpy(line, "STATE: ");
  strcat(line, paused ? "PAUSE" : "RUN");
  OLED_PrintASCIIString(0, 0,  line, &afont16x8, OLED_COLOR_NORMAL);

  strcpy(line, "DIR: ");
  strcat(line, wroktask ? "REV" : "FWD");
  OLED_PrintASCIIString(0, 16, line, &afont16x8, OLED_COLOR_NORMAL);

  strcpy(line, "STEP: ");
  strcat(line, stepStr);
  strcat(line, "ms");
  OLED_PrintASCIIString(0, 32, line, &afont16x8, OLED_COLOR_NORMAL);

  strcpy(line, "LED: ");
  strcat(line, ledNo == 1 ? "1" : (ledNo == 2 ? "2" : "3"));

  OLED_PrintASCIIString(0, 48, line, &afont16x8, OLED_COLOR_NORMAL);

  OLED_ShowFrame();

  static char txBuf[32];
  strcpy(txBuf, "LED:");
  strcat(txBuf, led);
  strcat(txBuf, "\r\n");
  HAL_UART_Transmit_DMA(&huart2, (uint8_t*)txBuf, strlen(txBuf));

}


/* USER CODE END Variables */
/* Definitions for LIGHT1 */
osThreadId_t LIGHT1Handle;
const osThreadAttr_t LIGHT1_attributes = {
  .name = "LIGHT1",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for LIGHT2 */
osThreadId_t LIGHT2Handle;
const osThreadAttr_t LIGHT2_attributes = {
  .name = "LIGHT2",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for KEY1 */
osThreadId_t KEY1Handle;
const osThreadAttr_t KEY1_attributes = {
  .name = "KEY1",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for myKEY2 */
osThreadId_t myKEY2Handle;
const osThreadAttr_t myKEY2_attributes = {
  .name = "myKEY2",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */


/* USER CODE END FunctionPrototypes */

void StartLIGHT1(void *argument);
void StartLIGHT2(void *argument);
void StartKEY1(void *argument);
void StartKEY2(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  HAL_UART_Receive_IT(&huart2, &rxByte, 1);

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of LIGHT1 */
  LIGHT1Handle = osThreadNew(StartLIGHT1, NULL, &LIGHT1_attributes);

  /* creation of LIGHT2 */
  LIGHT2Handle = osThreadNew(StartLIGHT2, NULL, &LIGHT2_attributes);

  /* creation of KEY1 */
  KEY1Handle = osThreadNew(StartKEY1, NULL, &KEY1_attributes);

  /* creation of myKEY2 */
  myKEY2Handle = osThreadNew(StartKEY2, NULL, &myKEY2_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartLIGHT1 */
/**
  * @brief  Function implementing the LIGHT1 thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartLIGHT1 */
void StartLIGHT1(void *argument)
{
  /* USER CODE BEGIN StartLIGHT1 */
  /* Infinite loop */
  for(;;)
  {
    if (wroktask==0) {
      HAL_GPIO_WritePin(RED_GPIO_Port, RED_Pin, GPIO_PIN_SET);
      HAL_GPIO_WritePin(YELLOW_GPIO_Port, YELLOW_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GREEN_GPIO_Port, GREEN_Pin, GPIO_PIN_RESET);
      OLED_ShowStatus();
      osDelay(stepMs);
      while (paused) osDelay(10);

      HAL_GPIO_WritePin(RED_GPIO_Port, RED_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(YELLOW_GPIO_Port, YELLOW_Pin, GPIO_PIN_SET);
      HAL_GPIO_WritePin(GREEN_GPIO_Port, GREEN_Pin, GPIO_PIN_RESET);
      OLED_ShowStatus();
      osDelay(stepMs);
      while (paused) osDelay(10);

      HAL_GPIO_WritePin(RED_GPIO_Port, RED_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(YELLOW_GPIO_Port, YELLOW_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GREEN_GPIO_Port, GREEN_Pin, GPIO_PIN_SET);
      OLED_ShowStatus();
      osDelay(stepMs);
      while (paused) osDelay(10);

    }else {
      osDelay(10);
    }

  }
  /* USER CODE END StartLIGHT1 */
}

/* USER CODE BEGIN Header_StartLIGHT2 */
/**
* @brief Function implementing the LIGHT2 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartLIGHT2 */
void StartLIGHT2(void *argument)
{
  /* USER CODE BEGIN StartLIGHT2 */
  /* Infinite loop */
  for(;;)
  {
    if (wroktask==1) {
      HAL_GPIO_WritePin(RED_GPIO_Port, RED_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(YELLOW_GPIO_Port, YELLOW_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GREEN_GPIO_Port, GREEN_Pin, GPIO_PIN_SET);
      OLED_ShowStatus();
      osDelay(stepMs);
      while (paused) osDelay(10);

      HAL_GPIO_WritePin(RED_GPIO_Port, RED_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(YELLOW_GPIO_Port, YELLOW_Pin, GPIO_PIN_SET);
      HAL_GPIO_WritePin(GREEN_GPIO_Port, GREEN_Pin, GPIO_PIN_RESET);
      OLED_ShowStatus();
      osDelay(stepMs);
      while (paused) osDelay(10);

      HAL_GPIO_WritePin(RED_GPIO_Port, RED_Pin, GPIO_PIN_SET);
      HAL_GPIO_WritePin(YELLOW_GPIO_Port, YELLOW_Pin, GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GREEN_GPIO_Port, GREEN_Pin, GPIO_PIN_RESET);
      OLED_ShowStatus();
      osDelay(stepMs);

      while (paused) osDelay(10);

    }else {
      osDelay(10);
    }

  }
  /* USER CODE END StartLIGHT2 */
}

/* USER CODE BEGIN Header_StartKEY1 */
/**
* @brief Function implementing the KEY1 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartKEY1 */
void StartKEY1(void *argument)
{uint8_t last=1;
  /* USER CODE BEGIN StartKEY1 */
  /* Infinite loop */
  for(;;)
  {

        uint8_t cur = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12);
        if (cur == GPIO_PIN_RESET && last == GPIO_PIN_SET)
        {
          wroktask = !wroktask;
          osDelay(20);
        }
        last = cur;
        osDelay(10);



  }
  /* USER CODE END StartKEY1 */
}

/* USER CODE BEGIN Header_StartKEY2 */
/**
* @brief Function implementing the myKEY2 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartKEY2 */
void StartKEY2(void *argument)
{uint8_t last=1;
  /* USER CODE BEGIN StartKEY2 */
  /* Infinite loop */
  for(;;) {
    uint8_t cur = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_15);
    if (cur == GPIO_PIN_RESET && last == GPIO_PIN_SET) {
      paused = !paused;
      OLED_ShowStatus();
      osDelay(20);
    }
    last = cur;
    osDelay(10);
  }
}





  /* USER CODE END StartKEY2 */


/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance != USART2) return;


  pktBuf[pktIdx++] = rxByte;
  if (pktIdx >= 6) {
    pktIdx = 0;
    if (pktBuf[0] == 0xAA) {


      uint8_t sum = pktBuf[0]+pktBuf[1]+pktBuf[2]+pktBuf[3]+pktBuf[4];
      if (sum == pktBuf[5]) {


        gPacket.run  = pktBuf[1];
        gPacket.dir  = pktBuf[2];
        gPacket.step = (uint16_t)(pktBuf[4] << 8) | pktBuf[3];
        if (gPacket.step < 100) gPacket.step = 100;
        if (gPacket.step > 2000) gPacket.step = 2000;
        paused   = (gPacket.run == 0);
        wroktask = (gPacket.dir == 0);
        stepMs   = gPacket.step;
      }
    }
  }
  HAL_UART_Receive_IT(&huart2, &rxByte, 1);   // 必须重新开启
}
/* USER CODE END Application */

